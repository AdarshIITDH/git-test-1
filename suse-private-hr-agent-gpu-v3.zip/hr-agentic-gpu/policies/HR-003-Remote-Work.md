# HR-003 — Remote Work Policy
Version: DEMO-1.0 | Effective date: 2026-10-01 | Company: Northstar Demo Technologies (fictional)

## Hybrid work
Eligible engineering and administrative employees may request up to two remote work days per week, subject to manager agreement. Specific client and operational roles may require on-site coverage.

## Process
Discuss planned remote days with the reporting manager before scheduling. The HR assistant can explain the policy but cannot approve or change a schedule.
