# HR-002 — Sick Leave Policy
Version: DEMO-1.0 | Effective date: 2026-10-01 | Company: Northstar Demo Technologies (fictional)

## Eligibility
Employees may request sick leave if their HRMS sick leave balance permits. The HRMS balance, not this document, is authoritative. Sick leave must not be presented as automatic medical advice.

## Medical evidence
For three or more consecutive working days, the employee should provide supporting documentation to HR through the designated private channel. Do not send medical documents to the AI chat application.

## Escalation
Sensitive health matters should be handled by HR staff, not by the demo agent.
