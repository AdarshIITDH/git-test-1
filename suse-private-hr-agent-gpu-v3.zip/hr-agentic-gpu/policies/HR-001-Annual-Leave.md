# HR-001 — Annual Leave Policy
Version: DEMO-1.0 | Effective date: 2026-10-01 | Company: Northstar Demo Technologies (fictional)

## Eligibility and balance
Full-time employees may request annual leave as long as they have sufficient remaining balance. The employee portal displays the authoritative balance from the HRMS, not from this policy document. Leave balances vary by employee. Unpaid leave requires a separate HR review.

## How leave days are calculated
Only scheduled working days (Monday through Friday) count against annual leave. Saturdays, Sundays, and company holidays are excluded. The company holiday calendar is authoritative and must be queried from HRMS for the requested period.

## Approval workflow
Requests are submitted as **PENDING** and require manager approval before they become approved leave. A draft or a chat answer is not approval. Employees must explicitly confirm any submission. The agent must not automatically submit or approve leave.

## Notice periods
Planned annual leave normally requires at least three working days' notice. Urgent leave may be submitted later but should be marked for manager review. This is a fictional demonstration rule.
