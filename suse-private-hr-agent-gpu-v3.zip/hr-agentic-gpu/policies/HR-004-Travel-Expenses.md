# HR-004 — Travel and Expense Policy
Version: DEMO-1.0 | Effective date: 2026-10-01 | Company: Northstar Demo Technologies (fictional)

## Business travel
Domestic business trips should be pre-approved by the reporting manager. Business-class air travel is not automatically reimbursable. Use the approved booking channel when applicable.

## Claims
Expense claims with supporting receipts should be submitted within 30 calendar days after the trip ends. Claims above INR 25,000 require finance review. This is sample data and not a representation of SUSE or Dell policies.
