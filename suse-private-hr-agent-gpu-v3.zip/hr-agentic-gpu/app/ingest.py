import json
from app.rag import ingest
if __name__ == '__main__':
    print(json.dumps(ingest('/code/policies'), indent=2))
