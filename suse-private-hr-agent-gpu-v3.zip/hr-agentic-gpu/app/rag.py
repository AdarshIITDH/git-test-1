"""CPU-only policy embeddings, with a Milvus service in Kubernetes."""
import os
from pathlib import Path
from functools import lru_cache
from pymilvus import MilvusClient

COLLECTION = "hr_policies"
MILVUS_URI = os.getenv("MILVUS_URI", "http://milvus:19530")
EMBED_MODEL = os.getenv("EMBED_MODEL", "sentence-transformers/all-MiniLM-L6-v2")

@lru_cache(maxsize=1)
def embedder():
    from sentence_transformers import SentenceTransformer
    return SentenceTransformer(EMBED_MODEL, device="cpu")


def milvus():
    return MilvusClient(uri=MILVUS_URI)


def chunks(text: str, size: int = 720, overlap: int = 110):
    text = text.strip()
    if not text:
        return
    at = 0
    while at < len(text):
        ending = min(at + size, len(text))
        if ending < len(text):
            cut = text.rfind("\n", at + 200, ending)
            if cut > at:
                ending = cut
        yield text[at:ending].strip()
        if ending == len(text):
            return
        at = max(at + 1, ending - overlap)


def ingest(path: str):
    client = milvus()
    model = embedder()
    if client.has_collection(COLLECTION):
        client.drop_collection(COLLECTION)  # demo rerunnable; not a production update strategy
    client.create_collection(collection_name=COLLECTION, dimension=384, auto_id=True, metric_type="COSINE", enable_dynamic_field=True)
    records = []
    for source in sorted(Path(path).glob("*.md")):
        for idx, chunk in enumerate(chunks(source.read_text(encoding="utf-8"))):
            records.append({"source":source.name, "section":str(idx + 1), "text":chunk})
    vectors = model.encode([r["text"] for r in records], normalize_embeddings=True).tolist()
    for row, vector in zip(records, vectors):
        row["vector"] = vector
    client.insert(collection_name=COLLECTION, data=records)
    client.flush(collection_name=COLLECTION)
    return {"collection": COLLECTION, "documents":len(list(Path(path).glob("*.md"))), "chunks":len(records)}


def search(query: str, limit: int = 4):
    client = milvus()
    if not client.has_collection(COLLECTION):
        raise RuntimeError("HR policy collection not initialized: run ingestion Job first")
    vector = embedder().encode([query], normalize_embeddings=True).tolist()
    results = client.search(collection_name=COLLECTION, data=vector, limit=limit, output_fields=["source","text","section"])
    return [{"source":hit["entity"]["source"],"section":hit["entity"]["section"],"text":hit["entity"]["text"],"score":round(float(hit["distance"]),3)} for hit in results[0]]
