# Upgrade an existing running RKE2 HR demo (v2 → v3)

**Goal:** apply the generic NVIDIA GPU/SLES UI and password-hash compatibility fix. This upgrade intentionally **does not change** `hrms`, SQLite data, `hrms-db`, Milvus, policy indexes, vLLM, LiteLLM, model cache, Rancher or GPU Operator.

1. Copy the ZIP to the Dell/SLES host. The ZIP extracts to a new directory, `hr-agentic-gpu`, leaving the current `hr-agentic-h200` folder alone.

```bash
cd /root
unzip -o suse-private-hr-agent-gpu-v3.zip
cd hr-agentic-gpu
export KUBECONFIG=/etc/rancher/rke2/rke2.yaml
kubectl -n hr-agentic get deploy hr-app hrms
kubectl -n hr-agentic get pods
```

2. Upgrade **only** `hr-app`:

```bash
bash deploy/update-v3-existing-rke2.sh
```

This script retains your existing `hr-demo-auth` Secret and sets a unique `v3-timestamp` app image tag each run. It backs up the original Deployment YAML to `reports/` for rollback. It **does not** redo SQL migrations or policy ingestion. It streams the image directly to the RKE2 containerd image store rather than leaving a .tar on disk. A second copy in Docker's local image/cache store is still possible; see `IMAGE_STORAGE.md`.

3. Verify:

```bash
kubectl -n hr-agentic rollout status deploy/hr-app
kubectl -n hr-agentic get deploy hr-app -o jsonpath='{.spec.template.spec.containers[0].image}'; echo
kubectl -n hr-agentic port-forward svc/hr-app 8080:8080
```

Use another terminal for `curl http://127.0.0.1:8080/api/health` and login. The health API should report `version: v3`.

**Rollback** to the previous image safely without restoring entire old Deployment YAML containing generated fields:

```bash
kubectl -n hr-agentic rollout history deployment/hr-app
kubectl -n hr-agentic rollout undo deployment/hr-app
kubectl -n hr-agentic rollout status deployment/hr-app
```

**Never run `configure-vllm-16gb.sh` on the Dell H200 just for this UI change.** It is for the *new* GPU system and deliberately changes model deployment.
