FROM python:3.11-slim
ENV PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
WORKDIR /code
COPY requirements-app.txt /code/
RUN pip install --no-cache-dir -r requirements-app.txt
COPY app/ /code/app/
COPY policies/ /code/policies/
COPY data/ /code/data/
EXPOSE 8080
CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8080"]
