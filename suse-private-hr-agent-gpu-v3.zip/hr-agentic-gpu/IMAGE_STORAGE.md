# Docker image transfer and disk usage on RKE2

Yes: **Docker and RKE2's containerd are separate image stores.** If you `docker build` and then import into RKE2, image layers can occupy space in BOTH Docker and containerd. `docker save -o image.tar` adds an extra temporary full archive. The built-in v3 upgrade script avoids that `.tar` by streaming:

```bash
docker build -f Dockerfile.app -t localhost/hr-agent-app:v3-example .
docker save localhost/hr-agent-app:v3-example | \
  /var/lib/rancher/rke2/bin/ctr --address /run/k3s/containerd/containerd.sock \
  --namespace k8s.io images import -
```

**After app rollout passes** you may remove only the locally built Docker image:

```bash
docker image rm localhost/hr-agent-app:v3-example
```

This does not guarantee full disk reclamation because Docker build cache may retain layers. Inspect `docker system df`, `du -sh /var/lib/docker`, and the RKE2 containerd filesystem first. Do **not** run broad `docker system prune --volumes`, `rm -rf` on containerd, or prune active RKE2 images. If Docker is used by other projects, global builder pruning can impact their rebuilds.

**Best for a separate SLES/RKE2 server:** build on a CI runner or laptop, push to a registry, and have RKE2 pull the image. Then the GPU server does not keep a separate Docker build cache. The containerd image store remains mandatory.

**Alternative for one-image-store builds:** `nerdctl` attached to RKE2 containerd + BuildKit can build into the containerd store directly, but only after validating its socket, permissions, BuildKit and snapshotter compatibility. Do not install a second container runtime just to optimize the POC.

Model download caches and Milvus PVCs are separate storage and must be sized and monitored independently.
