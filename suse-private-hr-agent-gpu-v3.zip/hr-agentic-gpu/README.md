# SUSE Private HR Agent v3 — NVIDIA GPU + SLES

**Fictional employee/manager HR demo** using FastAPI, Milvus RAG, HRMS MCP tools, SQLite, LiteLLM, vLLM and RKE2. UI labels say **NVIDIA GPU**, not a particular GPU SKU. Platform labels say **SUSE Linux Enterprise Server (SLES)**, not Ubuntu. An unverified decorative logo has been removed; the app retains SUSE-themed text/color styling, not an official logo asset.

## Which guide?

- Already running HR Agent v2? **[UPGRADE_RUNNING_CLUSTER.md](UPGRADE_RUNNING_CLUSTER.md)** — application-only upgrade; no model or DB changes.
- New server with **16 GiB available GPU VRAM**? **[DEPLOY_16GB_GPU.md](DEPLOY_16GB_GPU.md)** — uses 3B model and reuses the rest of the app.
- Have **SUSE AI Factory**? **[REUSE_SUSE_AI_FACTORY.md](REUSE_SUSE_AI_FACTORY.md)** — connect to a managed vLLM/Milvus stack rather than duplicating it.
- Disk and image transfer details: **[IMAGE_STORAGE.md](IMAGE_STORAGE.md)**.

## Components

| Role | Workload | Data |
| --- | --- | --- |
| Employee/manager web UI + agent | `hr-app` (FastAPI) | Reads from RAG/MCP, streams real agent traces |
| HRMS MCP server | `hrms` | SQLite file on `hrms-db` PVC |
| Policy vector search | Milvus | Five synthetic HR policy docs |
| Model API gateway | LiteLLM | Model alias `hr-agent` |
| GPU inference | vLLM | `hr-llm` model service, NVIDIA GPU |
| Orchestration | SUSE RKE2 on SLES | Optional Rancher Prime + SUSE AI Factory |

Employee and Manager demo accounts are role-scoped by the FastAPI session. Employee leaves are PENDING until an authorized manager approves/rejects. The UI shows real execution events from the backend; policy citations are retrieved through Milvus and HRMS records via MCP. **This is not production IAM.**

## Demo credentials

No built-in default passwords. The `hr-demo-auth` Kubernetes Secret is managed separately. v3 can validate both legacy *plaintext* demo credentials and PBKDF2-SHA256 hashes; it does not modify secrets when upgraded. For private test only use SSH tunnel rather than exposing login publicly.

## Test

```bash
python3 -m unittest discover -s tests -p 'test_*.py'
node --check tests/client.syntax.js
bash -n deploy/update-v3-existing-rke2.sh
```

Run in server once deployed:

```bash
kubectl -n hr-agentic get deploy,pods,svc,pvc
kubectl -n hr-agentic port-forward svc/hr-app 8080:8080
```

Windows laptop with SSH connection to the server:

```powershell
ssh -N -L 18080:127.0.0.1:8080 root@SERVER_IP
```

Open `http://127.0.0.1:18080` on laptop.

## Important constraints

- GPU-specific model and VRAM settings are configured in **`deploy/21-vllm-16gb.yaml`** (16 GB) versus **`deploy/20-vllm.yaml`** (larger GPU).
- Actual GPU model and memory must be verified with `nvidia-smi`; NVIDIA **L40S is a 48 GB card** (or a smaller vGPU profile may be presented).
- Do not use 14B FP16/BF16 on a single 16 GB GPU unless using appropriate quantization/multiple GPUs/offload, none of which is configured here.
- Never resize/recreate existing `hrms-db`, `hf-cache` or Milvus PVCs just to upgrade the UI.
- No official SUSE logo file is bundled; no logos are synthesized or copied from questionable sources.
- SLES is the **host OS**. Python images may use their own base distro inside containers, which does not change the SLES host.
