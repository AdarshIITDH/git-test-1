"""Check compatibility without importing optional deployment-only dependencies."""
import ast
import hashlib
import hmac
import unittest
from pathlib import Path

SRC = (Path(__file__).resolve().parents[1] / 'app/main.py').read_text()
NODE = next(x for x in ast.parse(SRC).body if isinstance(x, ast.FunctionDef) and x.name == 'verify_demo_password')
NS = {'hmac': hmac, 'hashlib': hashlib}
exec(compile(ast.Module(body=[NODE], type_ignores=[]), 'app/main.py', 'exec'), NS)
verify = NS['verify_demo_password']

class PasswordCompatibilityTests(unittest.TestCase):
    def test_legacy_plain(self):
        self.assertTrue(verify('1234', '1234'))
        self.assertFalse(verify('wrong', '1234'))
    def test_pbkdf2_demo(self):
        salt = 'abcd012345'
        digest = hashlib.pbkdf2_hmac('sha256', b'1234', salt.encode(), 260000).hex()
        hashed = f'pbkdf2_sha256$260000${salt}${digest}'
        self.assertTrue(verify('1234', hashed))
        self.assertFalse(verify('wrong', hashed))
        self.assertFalse(verify('1234', 'pbkdf2_sha256$invalid'))
