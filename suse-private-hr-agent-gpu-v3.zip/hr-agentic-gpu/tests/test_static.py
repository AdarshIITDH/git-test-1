"""No cluster needed: small checks runnable with stdlib unittest."""
import ast
import json
import unittest
from datetime import date, timedelta
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]

class StaticTests(unittest.TestCase):
    def test_python_syntax(self):
        for file in (ROOT/'app').glob('*.py'):
            ast.parse(file.read_text(encoding='utf-8'), filename=str(file))
        for file in (ROOT/'hrms').glob('*.py'):
            ast.parse(file.read_text(encoding='utf-8'), filename=str(file))
    def test_synthetic_employees(self):
        data = json.loads((ROOT/'data/hr_seed.json').read_text(encoding='utf-8'))
        self.assertEqual(len(data['employees']),10)
        self.assertEqual(len({e['id'] for e in data['employees']}),10)
        self.assertEqual(data['employees'][0]['annual_leave'],14)
    def test_policy_inventory(self):
        self.assertEqual(len(list((ROOT/'policies').glob('*.md'))),5)
    def test_demo_days(self):
        a, b = date(2026,11,2),date(2026,11,6)
        dates=[a+timedelta(days=i) for i in range((b-a).days+1)]
        self.assertEqual(len([d for d in dates if d.weekday()<5 and d.isoformat()!='2026-11-04']),4)

if __name__ == '__main__':
    unittest.main()
