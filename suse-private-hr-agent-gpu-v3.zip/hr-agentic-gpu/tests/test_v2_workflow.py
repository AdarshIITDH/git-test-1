"""Offline regression tests: SQLite migration/manager scope and session RBAC.

Uses stand-ins only for importing external services; HRMS database logic is real.
"""
import importlib
import os
import sys
import types
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))

# Permit local validation even where the optional network SDKs aren't installed.
try:
    from mcp.server.mcpserver import MCPServer
except ImportError:
    fake_mcp=types.ModuleType('mcp')
    fake_mcp.Client=object
    fake_mcp_server=types.ModuleType('mcp.server')
    fake_mcp_server_mcp=types.ModuleType('mcp.server.mcpserver')
    class StubServer:
        def __init__(self,*args,**kwargs): pass
        def tool(self): return lambda fn:fn
    fake_mcp_server_mcp.MCPServer=StubServer
    sys.modules['mcp']=fake_mcp
    sys.modules['mcp.server']=fake_mcp_server
    sys.modules['mcp.server.mcpserver']=fake_mcp_server_mcp
try:
    import pymilvus
except ImportError:
    pymilvus=types.ModuleType('pymilvus')
    pymilvus.MilvusClient=object
    sys.modules['pymilvus']=pymilvus

try:
    from openai import AsyncOpenAI
except ImportError:
    mock_openai=types.ModuleType('openai')
    mock_openai.AsyncOpenAI=object
    sys.modules['openai']=mock_openai


@pytest.fixture()
def db(tmp_path,monkeypatch):
    from hrms import server
    monkeypatch.setattr(server,'DB',tmp_path/'hr.sqlite')
    monkeypatch.setattr(server,'SEED',ROOT/'data/hr_seed.json')
    server.init_db()
    yield server


def test_manager_can_approve_only_direct_report_and_deducts_once(db):
    # Meera Nair's actual seed manager is Kabir Sethi (EMP005).
    r=db.submit('EMP004','2026-11-02','2026-11-06','Holiday trip')
    assert r['chargeable_days']==4
    assert db.balance('EMP004')['annual_leave_available']==16
    assert db.balance('EMP004')['annual_leave_pending_requests_days']==4
    assert db.employee_requests('EMP004')['requests'][0]['status']=='PENDING'
    with pytest.raises(ValueError, match='outside'):
        db.review('EMP007',r['request_id'],'APPROVED','Not my report')
    rows=db.manager_requests('EMP005')['requests']
    assert rows[0]['request_id']==r['request_id']
    result=db.review('EMP005',r['request_id'],'APPROVED','Approved after review')
    assert result['status']=='APPROVED'
    assert db.balance('EMP004')['annual_leave_available']==12
    assert db.balance('EMP004')['annual_leave_pending_requests_days']==0
    with pytest.raises(ValueError,match='already reviewed'):
        db.review('EMP005',r['request_id'],'APPROVED','Replay')
    assert db.balance('EMP004')['annual_leave_available']==12
    # Restarting init_db is idempotent and preserves stored approvals.
    db.init_db()
    assert db.manager_request('EMP005',r['request_id'])['status']=='APPROVED'
    assert db.balance('EMP004')['annual_leave_available']==12


def test_manager_reject_does_not_deduct(db):
    r=db.submit('EMP001','2026-12-02','2026-12-03','Family event')
    result=db.review('EMP007',r['request_id'],'REJECTED','Team coverage')
    assert result['status']=='REJECTED'
    assert db.balance('EMP001')['annual_leave_available']==14
    assert db.employee_requests('EMP001')['requests'][0]['manager_note']=='Team coverage'


def test_duplicate_or_overlapping_leave_blocked(db):
    db.submit('EMP001','2026-12-02','2026-12-03','Leave')
    with pytest.raises(ValueError,match='overlap'):
        db.submit('EMP001','2026-12-03','2026-12-04','Duplicate overlap')


def test_login_rbac_and_csrf(monkeypatch):
    from fastapi.testclient import TestClient
    monkeypatch.setenv('HR_EMPLOYEE_PASSWORD','employee-demo-only')
    monkeypatch.setenv('HR_MANAGER_PASSWORD','manager-demo-only')
    monkeypatch.setenv('HR_SESSION_SECRET','s'*64)
    import app.main
    importlib.reload(app.main)
    client=TestClient(app.main.app)
    opts=client.get('/api/auth/options').json()
    assert any(e['id']=='EMP005' for e in opts['managers'])
    assert not any(e['id']=='EMP004' for e in opts['managers'])
    assert client.get('/api/auth/me').status_code==401
    assert client.post('/api/auth/login',json={'role':'manager','user_id':'EMP004','password':'manager-demo-only'}).status_code==401
    assert client.post('/api/auth/login',json={'role':'employee','user_id':'EMP004','password':'employee-demo-only'}).status_code==200
    me=client.get('/api/auth/me').json()
    assert me['role']=='employee' and me['employee']['id']=='EMP004'
    assert client.get('/api/manager/requests').status_code==403
    assert client.post('/api/leave/submit',json={'start_date':'2026-11-02','end_date':'2026-11-06','reason':'Demo','confirmed':True}).status_code==403
    client.post('/api/auth/logout',headers={'X-CSRF-Token':me['csrf']})
    assert client.post('/api/auth/login',json={'role':'manager','user_id':'EMP005','password':'manager-demo-only'}).status_code==200
    assert client.get('/api/auth/me').json()['role']=='manager'
    assert client.get('/api/requests').status_code==403
