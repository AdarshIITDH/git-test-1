# Run SUSE Private HR Agent on SLES/RKE2 with ~16 GB GPU VRAM

## First check the REAL device

```bash
nvidia-smi --query-gpu=name,memory.total,driver_version --format=csv
kubectl get nodes -o wide
kubectl describe nodes | grep -E 'nvidia.com/gpu|Allocatable|Capacity'
kubectl get storageclass
kubectl get pods -A | grep -Ei 'gpu|vllm|milvus|litellm' || true
```

**L40S is 48 GB physical VRAM** according to NVIDIA's specifications. A 16 GB readout could be another model or a 16 GB vGPU allocation. Always select by reported available VRAM; avoid assuming the GPU SKU.

### If you already have RKE2 + GPU Operator + Milvus + LiteLLM + HRMS services

Reuse those services. Copy this project to the server and update only `hr-app` using `deploy/update-v3-existing-rke2.sh`. **No vLLM changes are needed** if LiteLLM's existing model is usable.

### If you need a new 16 GB vLLM service

The larger-GPU default `deploy/20-vllm.yaml` serves Qwen2.5-14B and is NOT appropriate on a 16 GB card. For 16 GB, use `deploy/21-vllm-16gb.yaml`, which provides:

- `Qwen/Qwen2.5-3B-Instruct`, FP16 (`--dtype half`)
- `--max-model-len 4096`
- `--gpu-memory-utilization 0.78`
- `--enable-auto-tool-choice --tool-call-parser hermes`
- preserved service name `hr-vllm:8000`, model alias `hr-llm`, `nvidia.com/gpu: 1`

If namespace and core services already exist, run:

```bash
kubectl get ns hr-agentic
kubectl -n hr-agentic get svc milvus litellm hrms
bash deploy/configure-vllm-16gb.sh
kubectl -n hr-agentic logs -f deployment/hr-vllm
```

The script backs up the existing `hr-vllm` Deployment YAML and creates a 30 GiB model-cache PVC **only when there is no existing one**. No new GPU Operator or model gateway is installed. The `vllm-openai:latest` image is a placeholder to be pinned after checking actual NVIDIA driver/CUDA compatibility; it is not claimed tested on your target GPU.

Check inference:

```bash
kubectl -n hr-agentic get pod -l app=hr-vllm
kubectl -n hr-agentic port-forward svc/hr-vllm 8000:8000
# in another terminal
curl -f http://127.0.0.1:8000/v1/models
```

If the GPU model is older and vLLM/CUDA compatibility fails, pick a supported vLLM image/version instead of force-upgrading the host driver or GPU Operator.

### Clean installation (no HR demo components yet)

On an already functioning **single-node SLES/RKE2** with an NVIDIA GPU Operator, `docker`, `helm`, `envsubst`, a default StorageClass and sufficient CPU RAM/disk, first install or reuse Milvus. Prefer an existing SUSE AI Factory-managed Milvus if available. If it is genuinely missing, the Milvus standalone Helm install example below sets smaller demo persistence (verify chart values against `helm show values` and actual storage capacity before running):

```bash
kubectl apply -f deploy/00-namespace.yaml
helm repo add zilliztech https://zilliztech.github.io/milvus-helm/
helm repo update
helm show values zilliztech/milvus > /tmp/milvus-chart-values.yaml
helm install milvus zilliztech/milvus -n hr-agentic \
  --set image.all.tag=v2.6.25 \
  --set cluster.enabled=false \
  --set etcd.replicaCount=1 \
  --set minio.mode=standalone \
  --set minio.persistence.size=20Gi \
  --set pulsarv3.enabled=false \
  --set standalone.messageQueue=woodpecker \
  --set woodpecker.enabled=true \
  --set streaming.enabled=true
kubectl -n hr-agentic get pods,pvc,svc
```

Chart availability, resources and storage values depend on actual chart version. **Do not apply to any existing Milvus release**; always size before use. Once `service/milvus` is reachable and all prerequisites work, install the remaining app/MCP/LiteLLM/vLLM and ingest five policy files:

```bash
bash deploy/install-new-16gb-rke2.sh
kubectl -n hr-agentic get pods,pvc,svc,jobs
kubectl -n hr-agentic port-forward svc/hr-app 8080:8080
```

The script deliberately refuses to run if `hrms-db` already exists. New cluster installs will fetch all container images and embedding/model weights, so allow adequate disk, RAM and network. AIF-managed external vLLM is an alternative to creating `hr-vllm`.

### Hardware planning

Model weights for 3B at FP16 are roughly 6 GB **before** KV cache and engine overhead; a 16 GB card can be feasible for this POC, not guaranteed. Inference performance and concurrency need live measurement. Reserve additional CPU RAM and disk for Milvus, embedding model, databases and model cache. Do not run a second vLLM instance when only one GPU is available and allocated.
