# Reuse SUSE AI Factory components instead of duplicating the AI stack

SUSE AI Factory provides a Rancher UI extension and Kubernetes operator to manage AI applications and **version-controlled blueprints**. Its AI building blocks can include **vLLM/Ollama** and **Milvus/Qdrant**. This app is an example custom blueprint or an external custom frontend built on top of those services, not a built-in SUSE HR product.

## Preferred mapping

| HR demo | Reuse from SUSE AI Factory when present | Keep project-specific |
| --- | --- | --- |
| GPU inference | Existing AIF-managed vLLM model endpoint | `hr-agent` LiteLLM model alias |
| RAG search | Existing AIF Milvus or Qdrant instance (Milvus supported by code) | HR policy collection/index |
| Runtime | SLES + RKE2, GPU Operator, Rancher | HR FastAPI agent and custom UI |
| Observability | SUSE Observability / OpenTelemetry | Request trace events (actual per-tool calls) |
| App management | Blueprint + Helm packaging/GitOps | HRMS MCP and SQLite demo seed |

Do not deploy another vLLM if AIF already serves a compatible tool-calling model. You need the exact model name and internal service URL, which may vary by AIF chart/blueprint.

## Repoint the existing LiteLLM alias (only if AIF endpoint exists)

Find the service and model name:

```bash
kubectl get svc -A | grep -Ei 'vllm|inference|milvus'
# Check the selected service's /v1/models endpoint using a port-forward or in-cluster curl.
```

Then configure (example placeholders; replace with verified values):

```bash
export VLLM_BASE_URL='http://<aif-vllm-service>.<namespace>.svc.cluster.local:8000/v1'
export VLLM_MODEL_NAME='<actual-model-name-from-v1-models>'
envsubst < deploy/31-litellm-shared-vllm.yaml | kubectl apply -f -
kubectl -n hr-agentic rollout restart deploy/litellm
kubectl -n hr-agentic rollout status deploy/litellm
```

This **changes the shared `litellm-config` ConfigMap and affects its existing consumers**. Verify whether other workloads use it, and back up the ConfigMap before updating:

```bash
kubectl -n hr-agentic get cm litellm-config -o yaml > litellm-config.backup.yaml
```

If you reuse AIF Milvus, set `MILVUS_URI` in the `hr-app` Deployment to the actual reachable Milvus endpoint (plus any required auth/NetworkPolicy). Ingest **only** the HR policy collection, without dropping other collections. If using Qdrant, `app/rag.py` requires an adapter; Qdrant is not a drop-in URI substitution for PyMilvus.

For a fuller SUSE AI Factory story, package the agent UI, HRMS MCP and policy-ingestion Job into a custom Helm component/blueprint. AIF's own operator manages the applications; it does not make the custom HRMS data source magically appear.

**Docs:** https://documentation.suse.com/suse-ai-factory/latest/ and https://documentation.suse.com/suse-ai-factory/latest/html/AI-Factory-bp-creating/index.html
