# v3 release notes

## Source changes
- Replaced hardware-specific **NVIDIA H200** and **Dell H200** UI/backend labels with **NVIDIA GPU**.
- Updated platform UI copy to **SLES / SUSE Linux Enterprise Server**; removed the decorative placeholder mark where a SUSE logo might be mistaken for an official asset. No official logo file is embedded.
- Fixed demo login hash mismatch: v3 supports plain Secret values from original starter and PBKDF2-SHA256 hashes written by external operations.
- Added 16 GB VRAM model profile: Qwen2.5-3B-Instruct, FP16, 4096-context, vLLM Hermes tool parser. This has NOT been benchmarked on target GPU.
- Added standalone new-cluster installer (requires Milvus installed separately) and safer app-only update script.
- Added option to route LiteLLM alias to an existing SUSE AI Factory-managed vLLM service.
- Changed app-only upgrade to stream Docker images into RKE2 containerd without writing intermediate tar file.
- Added docs about separate Docker/containerd storage, requirements, validation and rollbacks.

## Unchanged
- Frontend UX/navigation and all existing employee+manager workflows.
- Application API names, Service names, HRMS schema, SQLite PVC, Milvus collection, MCP tools and tracing schema.
- No cluster resources or live databases modified by generating this package.

## Verified here
- Python syntax, HTML-embedded JavaScript syntax, YAML parsing and Bash `-n`.
- Six standard-library unit tests including PBKDF2-compatible login verifier.
- Existing browser previews in v2 were not re-rendered; images were deliberately excluded from v3 to avoid showing obsolete GPU labels.

## Not validated
- NVIDIA GPU driver/vLLM image combination, GPU model and effective VRAM, pod readiness, Milvus chart sizing, Rancher and target RKE2 deployments; these require executing on the server.
