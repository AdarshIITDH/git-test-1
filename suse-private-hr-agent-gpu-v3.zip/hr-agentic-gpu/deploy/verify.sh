#!/usr/bin/env bash
set -euo pipefail
NS=hr-agentic
kubectl get node -o wide
kubectl get node -o jsonpath='{range .items[*]}{.metadata.name}{" => GPU allocatable: "}{.status.allocatable.nvidia\.com/gpu}{"\n"}{end}'
kubectl -n "$NS" get pods,pvc,svc
kubectl -n "$NS" get job/hr-policy-ingest
kubectl -n "$NS" logs job/hr-policy-ingest --tail=30 || true
kubectl -n "$NS" logs deploy/hr-vllm --tail=20 || true
