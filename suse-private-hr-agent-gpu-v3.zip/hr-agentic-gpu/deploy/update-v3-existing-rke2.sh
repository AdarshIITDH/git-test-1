#!/usr/bin/env bash
# Application-only update: does NOT touch the running HRMS DB, MCP deployment,
# Rancher, GPU Operator, vLLM, Milvus, LiteLLM, or model cache PVC.
set -euo pipefail
cd "$(dirname "$0")/.."
export KUBECONFIG="${KUBECONFIG:-/etc/rancher/rke2/rke2.yaml}"
NAMESPACE=hr-agentic
STAMP=$(date -u +%Y%m%dT%H%M%SZ)
export APP_IMAGE="${APP_IMAGE:-localhost/hr-agent-app:v3-$STAMP}"

for cmd in kubectl envsubst docker openssl; do
  command -v "$cmd" >/dev/null || { echo "Required command is missing: $cmd"; exit 1; }
done
CTR=/var/lib/rancher/rke2/bin/ctr
SOCK=/run/k3s/containerd/containerd.sock
[[ -x "$CTR" && -S "$SOCK" ]] || { echo 'RKE2 ctr/socket unavailable; use an image registry instead.'; exit 1; }
COUNT=$(kubectl get nodes --no-headers | wc -l)
[[ "$COUNT" -eq 1 ]] || { echo "Detected $COUNT nodes; use a shared registry/multi-node workflow."; exit 1; }
kubectl -n "$NAMESPACE" get deployment hr-app >/dev/null
kubectl -n "$NAMESPACE" get deployment hrms >/dev/null
kubectl -n "$NAMESPACE" get pvc hrms-db >/dev/null
kubectl -n "$NAMESPACE" get secret hr-litellm-secret >/dev/null

if ! kubectl -n "$NAMESPACE" get secret hr-demo-auth >/dev/null 2>&1; then
  echo 'Creating NEW demo login Secret (not touching HRMS records)...'
  read -rsp 'Employee demo password: ' E_PASSWORD; echo
  read -rsp 'Manager demo password: ' M_PASSWORD; echo
  [[ -n "$E_PASSWORD" && -n "$M_PASSWORD" ]] || { echo 'Passwords must not be empty'; exit 1; }
  kubectl -n "$NAMESPACE" create secret generic hr-demo-auth \
    --from-literal=employee-password="$E_PASSWORD" \
    --from-literal=manager-password="$M_PASSWORD" \
    --from-literal=session-secret="$(openssl rand -hex 32)"
  unset E_PASSWORD M_PASSWORD
else
  echo 'Existing demo login Secret retained. v3 understands plaintext or PBKDF2-SHA256 demo secrets.'
fi

mkdir -p reports
kubectl -n "$NAMESPACE" get deployment hr-app -o yaml > "reports/hr-app-before-$STAMP.yaml"
echo "Saved rollback manifest: reports/hr-app-before-$STAMP.yaml"
echo "Building $APP_IMAGE"
docker build -f Dockerfile.app -t "$APP_IMAGE" .
echo 'Streaming Docker image directly into RKE2 containerd (no intermediate .tar saved)...'
docker save "$APP_IMAGE" | "$CTR" --address "$SOCK" --namespace k8s.io images import -
"$CTR" --address "$SOCK" --namespace k8s.io images ls -q | grep -Fx "$APP_IMAGE" >/dev/null || {
  echo "Image $APP_IMAGE missing from RKE2 containerd after import"; exit 1;
}

echo 'Applying ONLY hr-app Deployment/Service...'
envsubst < deploy/40-backend.yaml | kubectl apply -f -
kubectl -n "$NAMESPACE" rollout status deployment/hr-app --timeout=300s
kubectl -n "$NAMESPACE" get pods -l app=hr-app -o wide
printf '\nApp updated to %s\n' "$APP_IMAGE"
echo 'No .tar file created. Docker build cache/source image still occupies Docker storage.'
echo 'Optional AFTER verifying the live app: docker image rm '"$APP_IMAGE"
echo 'Do NOT prune containerd/RKE2 images in use.'
