#!/usr/bin/env bash
# Clean new one-node RKE2 demo. Pre-req: namespace-independent GPU Operator, working
# default storage class, and an already running Milvus service named milvus in hr-agentic.
# Avoid running on an existing HR demo namespace with persistent data.
set -euo pipefail
cd "$(dirname "$0")/.."
export KUBECONFIG="${KUBECONFIG:-/etc/rancher/rke2/rke2.yaml}"
for cmd in kubectl envsubst docker openssl; do command -v "$cmd" >/dev/null || { echo "Missing $cmd"; exit 1; }; done
CTR=/var/lib/rancher/rke2/bin/ctr
SOCK=/run/k3s/containerd/containerd.sock
[[ -x "$CTR" && -S "$SOCK" ]] || { echo 'RKE2 containerd unavailable'; exit 1; }
[[ $(kubectl get nodes --no-headers | wc -l) -eq 1 ]] || { echo 'One-node workflow only; use shared registry for mult-node'; exit 1; }
if kubectl -n hr-agentic get pvc hrms-db >/dev/null 2>&1; then
  echo 'Existing hrms-db detected: refusing to overwrite existing demo. Use update-v3-existing-rke2.sh.'
  exit 1
fi
kubectl apply -f deploy/00-namespace.yaml
kubectl -n hr-agentic get svc milvus >/dev/null || { echo 'Milvus Service "milvus" missing in hr-agentic. Install/reuse Milvus first.'; exit 1; }
kubectl get storageclass | grep -q '(default)' || { echo 'Default StorageClass missing; configure PVC storage first.'; exit 1; }
GPU_NODES=$(kubectl get nodes -o json | python3 -c 'import json,sys; d=json.load(sys.stdin); print(sum(int(x.get("status",{}).get("allocatable",{}).get("nvidia.com/gpu",0)) for x in d["items"]))')
[[ "$GPU_NODES" -ge 1 ]] || { echo 'Kubernetes reports no NVIDIA GPU; verify GPU Operator/device plugin.'; exit 1; }

read -rsp 'Employee demo password: ' EPASS; echo
read -rsp 'Manager demo password: ' MPASS; echo
[[ -n "$EPASS" && -n "$MPASS" ]] || { echo 'Password cannot be empty'; exit 1; }
kubectl -n hr-agentic create secret generic hr-demo-auth \
  --from-literal=employee-password="$EPASS" \
  --from-literal=manager-password="$MPASS" \
  --from-literal=session-secret="$(openssl rand -hex 32)"
unset EPASS MPASS
kubectl -n hr-agentic create secret generic hr-litellm-secret \
  --from-literal=master-key="sk-$(openssl rand -hex 24)"

STAMP=$(date -u +%Y%m%dT%H%M%SZ)
export APP_IMAGE="localhost/hr-agent-app:v3-$STAMP"
export MCP_IMAGE="localhost/hr-agent-mcp:v3-$STAMP"
for spec in 'app Dockerfile.app' 'mcp Dockerfile.mcp'; do
  set -- $spec
  if [[ "$1" = app ]]; then image="$APP_IMAGE"; else image="$MCP_IMAGE"; fi
  docker build -f "$2" -t "$image" .
  docker save "$image" | "$CTR" --address "$SOCK" --namespace k8s.io images import -
done
for resource in deploy/10-hrms.yaml deploy/30-litellm.yaml deploy/40-backend.yaml; do
  envsubst < "$resource" | kubectl apply -f -
done
kubectl apply -f deploy/22-hf-cache-pvc-new-cluster.yaml
kubectl apply -f deploy/21-vllm-16gb.yaml
kubectl -n hr-agentic rollout status deployment/hrms --timeout=300s
kubectl -n hr-agentic rollout status deployment/hr-app --timeout=300s
kubectl -n hr-agentic rollout status deployment/litellm --timeout=300s
kubectl -n hr-agentic rollout status deployment/hr-vllm --timeout=1200s
# This is a new instance. Do not ingest over an existing collection.
envsubst < deploy/50-ingest-job.yaml | kubectl apply -f -
kubectl -n hr-agentic wait --for=condition=complete job/hr-policy-ingest --timeout=900s
kubectl -n hr-agentic get pods,svc,pvc,jobs
printf 'Demo installed. Run kubectl -n hr-agentic port-forward svc/hr-app 8080:8080\n'
