#!/usr/bin/env bash
# Explicit opt-in: replace the namespace-local hr-vllm Deployment with a 3B/16GB profile.
# NEVER run when using a shared SUSE AI Factory vLLM service.
set -euo pipefail
cd "$(dirname "$0")/.."
export KUBECONFIG="${KUBECONFIG:-/etc/rancher/rke2/rke2.yaml}"
N=hr-agentic
kubectl get namespace "$N" >/dev/null
kubectl get nodes -o wide
kubectl describe nodes | grep -E 'nvidia.com/gpu|Allocatable|Capacity' || true
[[ -n "$(kubectl -n "$N" get secret hr-litellm-secret -o name 2>/dev/null)" ]] || echo 'WARNING: LiteLLM secret not found; check rest of stack.'
if ! kubectl -n "$N" get pvc hf-cache >/dev/null 2>&1; then
  kubectl apply -f deploy/22-hf-cache-pvc-new-cluster.yaml
else
  echo 'Keeping existing hf-cache PVC, no resizing or deletion.'
fi
mkdir -p reports
if kubectl -n "$N" get deployment hr-vllm >/dev/null 2>&1; then
  STAMP=$(date -u +%Y%m%dT%H%M%SZ)
  kubectl -n "$N" get deployment hr-vllm -o yaml > "reports/hr-vllm-before-16gb-$STAMP.yaml"
  echo "Saved rollback: reports/hr-vllm-before-16gb-$STAMP.yaml"
fi
kubectl apply -f deploy/21-vllm-16gb.yaml
kubectl -n "$N" rollout status deployment/hr-vllm --timeout=900s
kubectl -n "$N" get pods -l app=hr-vllm
