"""Fictional HRMS: persistent SQLite and real Streamable HTTP MCP tools.

Demo-only identity: gateway assigns the current employee/manager; this MCP server
must not be directly exposed outside the cluster. Never connect to real HR data.
"""
import json
import os
import sqlite3
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

from mcp.server.mcpserver import MCPServer

DB = Path(os.environ.get('HR_DB', '/data/hr.sqlite'))
SEED = Path(os.environ.get('HR_SEED_FILE', str(Path(__file__).resolve().parent.parent / 'data/hr_seed.json')))


def connect():
    DB.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(DB, timeout=20)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA busy_timeout=20000')
    return db


def init_db():
    seed = json.loads(SEED.read_text(encoding='utf-8'))
    with connect() as db:
        db.execute('''CREATE TABLE IF NOT EXISTS employees (
            id TEXT PRIMARY KEY, name TEXT NOT NULL, department TEXT, role TEXT,
            manager TEXT, location TEXT, annual_leave INTEGER NOT NULL,
            sick_leave INTEGER NOT NULL)''')
        db.execute('''CREATE TABLE IF NOT EXISTS holidays (
            date TEXT PRIMARY KEY, name TEXT NOT NULL, scope TEXT NOT NULL)''')
        db.execute('''CREATE TABLE IF NOT EXISTS leave_requests (
            request_id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_id TEXT NOT NULL, start_date TEXT NOT NULL, end_date TEXT NOT NULL,
            chargeable_days INTEGER NOT NULL, reason TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'PENDING', created_at TEXT DEFAULT CURRENT_TIMESTAMP)''')
        fields = {x['name'] for x in db.execute('PRAGMA table_info(leave_requests)')}
        for col, typename in [('reviewed_by', 'TEXT'), ('reviewed_at', 'TEXT'), ('manager_note', 'TEXT')]:
            if col not in fields:
                db.execute(f'ALTER TABLE leave_requests ADD COLUMN {col} {typename}')
        for e in seed['employees']:
            db.execute('''INSERT OR IGNORE INTO employees
                (id,name,department,role,manager,location,annual_leave,sick_leave)
                VALUES (:id,:name,:department,:role,:manager,:location,:annual_leave,:sick_leave)''', e)
        for h in seed['holidays']:
            db.execute('INSERT OR IGNORE INTO holidays (date,name,scope) VALUES (:date,:name,:scope)', h)


def workdays(start: date, end: date, holidays: set[str]):
    if end < start or (end-start).days > 60:
        raise ValueError('Date range must be ordered and no longer than 61 days')
    days, cursor = 0, start
    while cursor <= end:
        if cursor.weekday() < 5 and cursor.isoformat() not in holidays:
            days += 1
        cursor += timedelta(days=1)
    return days


def profile(employee_id):
    with connect() as db:
        row = db.execute('SELECT id,name,department,role,manager,location FROM employees WHERE id=?',(employee_id,)).fetchone()
    if not row:
        raise ValueError('Unknown employee')
    return dict(row)


def balance(employee_id):
    with connect() as db:
        row = db.execute('SELECT id,annual_leave,sick_leave FROM employees WHERE id=?',(employee_id,)).fetchone()
        pending = db.execute("SELECT COALESCE(SUM(chargeable_days),0) AS pending_days FROM leave_requests WHERE employee_id=? AND status='PENDING'",(employee_id,)).fetchone()
    if not row:
        raise ValueError('Unknown employee')
    return {'employee_id':employee_id,'annual_leave_available':row['annual_leave'],
            'sick_leave_available':row['sick_leave'],
            'annual_leave_pending_requests_days':pending['pending_days'],
            'note':'Pending leave does not reduce the balance until manager approval'}


def holidays_between(start_date, end_date):
    start, end = date.fromisoformat(start_date), date.fromisoformat(end_date)
    if start > end or (end-start).days > 366:
        raise ValueError('Invalid holiday date range')
    with connect() as db:
        rows = db.execute('SELECT date,name,scope FROM holidays WHERE date BETWEEN ? AND ? ORDER BY date',(start_date,end_date)).fetchall()
    return {'start_date':start_date, 'end_date':end_date, 'holidays':[dict(r) for r in rows], 'calendar':'fictional company demo'}


def leave_rows(where, values):
    with connect() as db:
        rows = db.execute('''SELECT r.*, e.name AS employee_name, e.department,
            e.manager, e.role AS employee_role, e.annual_leave AS current_annual_balance
            FROM leave_requests r INNER JOIN employees e ON e.id=r.employee_id
            WHERE ''' + where + ' ORDER BY r.created_at DESC, r.request_id DESC', values).fetchall()
    return [dict(r) for r in rows]


def employee_requests(employee_id):
    profile(employee_id)
    return {'requests':leave_rows('r.employee_id=?',(employee_id,))}


def manager_requests(manager_id):
    manager = profile(manager_id)
    rows = leave_rows('e.manager=?',(manager['name'],))
    return {'manager':manager, 'team_size':team_size(manager['name']), 'requests':rows}


def team_size(manager_name):
    with connect() as db:
        return db.execute('SELECT COUNT(*) FROM employees WHERE manager=?',(manager_name,)).fetchone()[0]


def manager_request(manager_id, request_id):
    manager = profile(manager_id)
    rows = leave_rows('r.request_id=? AND e.manager=?',(request_id, manager['name']))
    if not rows:
        raise ValueError('Leave request not found in your reporting team')
    return rows[0]


def submit(employee_id, start_date, end_date, reason):
    start, end = date.fromisoformat(start_date), date.fromisoformat(end_date)
    if end < start or (end-start).days > 60:
        raise ValueError('Invalid leave date range')
    if not reason or len(reason) > 300:
        raise ValueError('Invalid reason')
    with connect() as db:
        db.execute('BEGIN IMMEDIATE')
        emp = db.execute('SELECT annual_leave FROM employees WHERE id=?',(employee_id,)).fetchone()
        if not emp:
            raise ValueError('Unknown employee')
        holiday_rows = db.execute('SELECT date FROM holidays WHERE date BETWEEN ? AND ?', (start_date,end_date)).fetchall()
        count = workdays(start, end, {h['date'] for h in holiday_rows})
        if count < 1:
            raise ValueError('No working days in requested period')
        reserved = db.execute("SELECT COALESCE(SUM(chargeable_days),0) FROM leave_requests WHERE employee_id=? AND status='PENDING'",(employee_id,)).fetchone()[0]
        overlapping = db.execute("""SELECT COUNT(*) FROM leave_requests
           WHERE employee_id=? AND status IN ('PENDING','APPROVED') AND start_date<=? AND end_date>=?""",
           (employee_id,end_date,start_date)).fetchone()[0]
        if overlapping:
            raise ValueError('Dates overlap an existing pending or approved request')
        if count + reserved > emp['annual_leave']:
            raise ValueError('Insufficient available leave after pending requests')
        cur = db.execute("""INSERT INTO leave_requests
           (employee_id,start_date,end_date,chargeable_days,reason,status)
           VALUES (?,?,?,?,?,'PENDING')""",(employee_id,start_date,end_date,count,reason.strip()))
        request_id = cur.lastrowid
    return {'request_id':request_id,'employee_id':employee_id,'start_date':start_date,
            'end_date':end_date,'chargeable_days':count,'status':'PENDING',
            'message':'Submitted to reporting manager; no balance deducted yet'}


def review(manager_id, request_id, decision, comment):
    if decision not in ('APPROVED','REJECTED'):
        raise ValueError('Decision must be APPROVED or REJECTED')
    if len(comment) > 500:
        raise ValueError('Manager note is too long')
    with connect() as db:
        db.execute('BEGIN IMMEDIATE')
        manager = db.execute('SELECT name FROM employees WHERE id=?',(manager_id,)).fetchone()
        if manager is None:
            raise ValueError('Unknown manager')
        req = db.execute('''SELECT r.*, e.manager, e.annual_leave FROM leave_requests r
             INNER JOIN employees e ON e.id=r.employee_id WHERE r.request_id=?''',(request_id,)).fetchone()
        if not req or req['manager'] != manager['name']:
            raise ValueError('Request is outside your reporting team')
        if req['status'] != 'PENDING':
            raise ValueError('Request already reviewed; no second decision allowed')
        if decision == 'APPROVED':
            if req['annual_leave'] < req['chargeable_days']:
                raise ValueError('Not enough leave remains to approve')
            updated = db.execute('''UPDATE employees SET annual_leave=annual_leave-?
                WHERE id=? AND annual_leave>=?''',
                (req['chargeable_days'],req['employee_id'],req['chargeable_days']))
            if updated.rowcount != 1:
                raise ValueError('Insufficient balance')
        at = datetime.now(timezone.utc).isoformat()
        db.execute('''UPDATE leave_requests SET status=?, reviewed_by=?, reviewed_at=?,
                    manager_note=? WHERE request_id=? AND status='PENDING' ''',
                   (decision,manager_id,at,comment.strip(),request_id))
    return {'request_id':request_id,'employee_id':req['employee_id'],
            'status':decision,'reviewed_by':manager_id,'reviewed_at':at,
            'chargeable_days':req['chargeable_days'],
            'message':'Leave approved and balance deducted' if decision=='APPROVED'
                      else 'Leave rejected; balance unchanged'}


mcp = MCPServer('Fictional HRMS MCP')

@mcp.tool()
def get_employee_profile(employee_id: str) -> dict:
    """Get a fictional employee profile; gateway enforces identity."""
    return profile(employee_id)

@mcp.tool()
def get_leave_balance(employee_id: str) -> dict:
    """Get employee current leave balances and pending days."""
    return balance(employee_id)

@mcp.tool()
def get_holiday_calendar(start_date: str, end_date: str) -> dict:
    """Fetch holidays for an inclusive date window."""
    return holidays_between(start_date,end_date)

@mcp.tool()
def submit_leave_request(employee_id: str, start_date: str, end_date: str, reason: str = 'Annual leave') -> dict:
    """Create a PENDING request, requiring a separate manager decision."""
    return submit(employee_id,start_date,end_date,reason)

@mcp.tool()
def get_employee_leave_requests(employee_id: str) -> dict:
    """List an employee's own leave requests."""
    return employee_requests(employee_id)

@mcp.tool()
def get_manager_leave_requests(manager_id: str) -> dict:
    """List requests of direct reports to the given manager."""
    return manager_requests(manager_id)

@mcp.tool()
def get_manager_leave_request(manager_id: str, request_id: int) -> dict:
    """Fetch request details only for manager's direct reports."""
    return manager_request(manager_id,request_id)

@mcp.tool()
def review_leave_request(manager_id: str, request_id: int, decision: str, comment: str = '') -> dict:
    """Explicit manager human approval or rejection; enforces reporting line."""
    return review(manager_id,request_id,decision,comment)

if __name__=='__main__':
    init_db()
    mcp.run(transport='streamable-http',host='0.0.0.0',port=7000,stateless_http=True,json_response=True)
